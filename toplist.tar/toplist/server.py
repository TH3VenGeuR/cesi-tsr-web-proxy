from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
import socket
import subprocess
import json

PORT = 8000

def get_system_info():
    hostname = socket.gethostname()
    ip = json.loads(
        subprocess.run(
            ['ip', '-j', 'a'],
            capture_output=True
        ).stdout.decode()
    )[1]['addr_info'][0]['local']
    return {"hostname": hostname, "ip": ip}

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)

        if parsed.path == "/info":
            info = get_system_info()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(info).encode())
            return

        if parsed.path == "/":
            params = parse_qs(parsed.query)
            page = params.get("page", ["list"])[0]

            try:
                with open("index.html", "r", encoding="utf-8") as f:
                    html = f.read()
            except FileNotFoundError:
                self.send_error(500)
                return

            html = html.replace("{{PAGE}}", page)

            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(html.encode())
            return

        super().do_GET()

server = HTTPServer(("0.0.0.0", PORT), Handler)
print(f"Serveur lancé sur http://localhost:{PORT}")
server.serve_forever()
